package com.jgy36.PoliticalApp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication(scanBasePackages = "com.jgy36.PoliticalApp")
public class PoliticalAppApplication {

    public static void main(String[] args) {
        SpringApplication.run(PoliticalAppApplication.class, args);
    }

}
