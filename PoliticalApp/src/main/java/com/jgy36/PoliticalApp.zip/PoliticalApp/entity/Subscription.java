package com.jgy36.PoliticalApp.entity;

public class Subscription {

}
