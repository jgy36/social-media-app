/* eslint-disable @typescript-eslint/no-explicit-any */
import { createSlice, PayloadAction, createAsyncThunk } from "@reduxjs/toolkit";
import { getCookie, setCookie, deleteCookie } from "cookies-next";
import { fetchWithToken } from "@/utils/api"; // ✅ Ensure correct import

interface UserState {
  token: string | null;
  username: string | null;
}

const initialState: UserState = {
  token: typeof getCookie("token") === "string" ? (getCookie("token") as string) : null,
  username: typeof getCookie("username") === "string" ? (getCookie("username") as string) : null,
};

export const loginUser = createAsyncThunk(
  "user/login",
  async ({ email, password }: { email: string; password: string }, { rejectWithValue }) => {
    try {
      const response = await fetchWithToken("/auth/login", "POST", { email, password });
      
      if (!response.token) {
        throw new Error("Login failed, no token received");
      }

      // ✅ Store token in cookies and state
      setCookie("token", response.token);
      setCookie("username", response.username);

      return { token: response.token, username: response.username };
    } catch (error: any) {
      return rejectWithValue(error.message);
    }
  }
);

export const registerUser = createAsyncThunk(
  "user/register",
  async ({ username, email, password }: { username: string; email: string; password: string }, { rejectWithValue }) => {
    try {
      const response = await fetchWithToken("/auth/register", "POST", { username, email, password });
      return response;
    } catch (error: any) {
      return rejectWithValue(error.message);
    }
  }
);

const userSlice = createSlice({
  name: "user",
  initialState,
  reducers: {
    logoutUser: (state) => {
      state.token = null;
      state.username = null;
      deleteCookie("token");
      deleteCookie("username");
    },
  },
  extraReducers: (builder) => {
    builder.addCase(
      loginUser.fulfilled,
      (state, action: PayloadAction<{ token: string; username: string }>) => {
        state.token = action.payload.token;
        state.username = action.payload.username;
      }
    );
  },
});

export const { logoutUser } = userSlice.actions;
export default userSlice.reducer;
