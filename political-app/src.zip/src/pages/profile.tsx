import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { DropdownMenu, DropdownMenuContent, DropdownMenuTrigger, DropdownMenuItem } from "@/components/ui/dropdown-menu";
import Navbar from "@/components/navbar/Navbar";
import { LogOut, Settings, Sun, Moon } from "lucide-react";
import { useDispatch } from "react-redux";
import { AppDispatch } from "@/redux/store";
import { logoutUser } from "@/redux/slices/userSlice";
import { useRouter } from "next/router";
import Image from "next/image";
import { useTheme } from "@/hooks/useTheme"; // ✅ Import Dark Mode Hook


const Profile = () => {
  const dispatch = useDispatch<AppDispatch>();
  const router = useRouter();
    const { theme, setTheme } = useTheme(); // ✅ Get theme & toggle function


  const handleLogout = () => {
    dispatch(logoutUser());
    router.push("/login");
  };

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* ✅ Sticky Navbar */}
      <Navbar />

      {/* ✅ Profile Header Section */}
      <div className="relative w-full max-w-3xl mx-auto">
        {/* Profile Banner */}
        <div className="w-full h-40 bg-gray-800 rounded-t-xl"></div>

        {/* Profile Picture */}
        <div className="absolute -bottom-10 left-6 w-24 h-24 border-4 border-background rounded-full overflow-hidden">
          <Image
            src="/profile-pic.jpg"
            alt="Profile Picture"
            width={96}
            height={96}
            className="rounded-full"
          />
        </div>
      </div>

      {/* ✅ User Info & Actions */}
      <div className="max-w-3xl mx-auto px-6 mt-12">
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-xl font-bold">John Doe</h1>
            <p className="text-gray-500">@johndoe</p>
          </div>
          <div className="flex gap-2">
            <Button variant="outline">Follow</Button>
            <Button variant="secondary">Message</Button>

            {/* ✅ Settings Dropdown with Dark Mode Toggle */}
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" className="rounded-full">
                  <Settings className="h-5 w-5" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-48">
                <DropdownMenuItem>Profile Settings</DropdownMenuItem>
                <DropdownMenuItem>Privacy Settings</DropdownMenuItem>

                {/* 🌗 Dark Mode Toggle */}
                <DropdownMenuItem onClick={() => setTheme(theme === "dark" ? "light" : "dark")}>
                  {theme === "dark" ? (
                    <>
                      <Sun className="h-4 w-4 mr-2" /> Light Mode
                    </>
                  ) : (
                    <>
                      <Moon className="h-4 w-4 mr-2" /> Dark Mode
                    </>
                  )}
                </DropdownMenuItem>

                {/* 🚪 Logout Button */}
                <DropdownMenuItem onClick={handleLogout} className="text-red-600">
                  <LogOut className="h-4 w-4 mr-2" /> Logout
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
        
        

        {/* ✅ User Stats */}
        <div className="flex gap-6 mt-2 text-sm text-gray-400">
          <span>
            <strong className="text-foreground">500</strong> Following
          </span>
          <span>
            <strong className="text-foreground">2.1K</strong> Followers
          </span>
          <span>
            <strong className="text-foreground">345</strong> Posts
          </span>
        </div>

        {/* ✅ User Bio */}
        <p className="mt-4 text-sm">
          🚀 Full-Stack Developer | JavaScript, React, Next.js | Building cool things!
        </p>
      </div>

      {/* ✅ Posts Section */}
      <div className="max-w-3xl mx-auto px-6 mt-6">
        <h2 className="text-lg font-semibold">Posts</h2>
        <Card className="p-4 mt-4">
          <p className="text-sm">
            Just finished working on an amazing project! 🚀 #WebDev #ReactJS
          </p>
          <div className="mt-2 flex justify-between text-gray-500 text-sm">
            <span>💬 12 Comments</span>
            <span>🔁 34 Retweets</span>
            <span>❤️ 87 Likes</span>
          </div>
        </Card>

        <Card className="p-4 mt-4">
          <p className="text-sm">Trying out Tailwind CSS for the first time. So clean! 💙</p>
          <div className="mt-2 flex justify-between text-gray-500 text-sm">
            <span>💬 8 Comments</span>
            <span>🔁 15 Retweets</span>
            <span>❤️ 54 Likes</span>
          </div>
        </Card>
      </div>
    </div>
  );
};

export default Profile;
