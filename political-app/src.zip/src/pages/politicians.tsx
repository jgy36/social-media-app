import Navbar from "@/components/navbar/Navbar";
import PoliticianList from "@/components/politicians/PoliticianList";

const Politicians = () => {
  return (
    <div>
      <Navbar />
      <div className="container mx-auto p-4">
        <h1 className="text-2xl font-bold">Politicians</h1>
        <PoliticianList />
      </div>
    </div>
  );
};

export default Politicians;

