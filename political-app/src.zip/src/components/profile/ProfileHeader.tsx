const ProfileHeader = () => {
  return (
    <div className="bg-blue-500 text-white p-4">
      <h2 className="text-lg font-bold">Username</h2>
      <p>@handle</p>
    </div>
  );
};

export default ProfileHeader;
