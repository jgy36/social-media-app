const ProfilePosts = () => {
  return (
    <div>
      <h2 className="text-lg font-bold">Your Posts</h2>
      <p>List of user posts...</p>
    </div>
  );
};

export default ProfilePosts;
